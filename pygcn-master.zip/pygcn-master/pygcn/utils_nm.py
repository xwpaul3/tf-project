import numpy as np
import scipy.sparse as sp
import torch

import pandas as pd

# 转换成onehot
# 需要的数据文件是rsvps.csv : 索引换为人，中间列是event，最后是group


def encode_onehot(labels):
    classes = set(labels)
    classes_dict = {c: np.identity(len(classes))[i, :] for i, c in
                    enumerate(classes)}
    labels_onehot = np.array(list(map(classes_dict.get, labels)),
                             dtype=np.int32)
    return labels_onehot


def load_data(path='../data/nashville-meetup/',dataset='Nashville-Meetup'):
    print('Loading {} dataset...'.format(dataset))
    idx_features_labels = pd.read_csv(path+'rsvps.csv',usecols = ['member_id','event_id','group_id'])
    labels = encode_onehot(idx_features_labels['group_id'])
    features = encode_onehot(idx_features_labels['event_id'])

    ## 构建图
    dx = np.array(idx_features_labels[:, 1], dtype=np.int32)
    idx_map = {j: i for i, j in enumerate(idx)}
    # ## 引用关系作为边，并存储为字典形式，再转化为array存为edges
    edges_unordered = np.genfromtxt("../data/nashville-meetup/member-edges.txt",dtype=np.int32)
    edges = np.array(list(map(idx_map.get, edges_unordered.flatten())),
                     dtype=np.int32).reshape(edges_unordered.shape)
    # ## 构建邻接矩阵：稀疏矩阵即可，再将其对称化。（无向图）
    adj = sp.coo_matrix((np.ones(edges.shape[0]), (edges[:, 0], edges[:, 1])),
                        shape=(labels.shape[0], labels.shape[0]),
                        dtype=np.float32)
    adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)
    # # 将特征部分进行行标准化
    features = normalize(features)
    adj = normalize(adj + sp.eye(adj.shape[0]))

    idx_train = range(1000)
    idx_val = range(2000, 5000)
    idx_test = range(5000, 15000)
        
    features = torch.FloatTensor(np.array(features.todense()))
    labels = torch.LongTensor(np.where(labels)[1])
    adj = sparse_mx_to_torch_sparse_tensor(adj)

    idx_train = torch.LongTensor(idx_train)
    idx_val = torch.LongTensor(idx_val)
    idx_test = torch.LongTensor(idx_test)

    return adj, features, labels, idx_train, idx_val, idx_test


def normalize(mx):
    """Row-normalize sparse matrix"""
    # # 一个文章的特征数
    rowsum = np.array(mx.sum(1))
    # # 特征数分之一/二作为每个特征的权重
    r_inv = np.power(rowsum, -2).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    return mx


def accuracy(output, labels):
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()
    correct = correct.sum()
    return correct / len(labels)


def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    """Convert a scipy sparse matrix to a torch sparse tensor."""
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)
